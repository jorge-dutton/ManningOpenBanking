# Better Banking

### Startup: 

    ./gradlew bootRun
