package betterbanking;

import io.betterbanking.BetterBankingApplication;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = {BetterBankingApplication.class})
class BetterBankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
